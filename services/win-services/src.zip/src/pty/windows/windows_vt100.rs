use super::PtySize;
use anyhow::{Context, Result};
use bytes::Bytes;
use std::io::{BufReader, Read, Write};
use std::process::{Command, Stdio};
use std::sync::{Arc, Mutex};
use std::thread;
use tokio::sync::mpsc;
use vt100::Parser;

pub struct PtyProcessInner {
    pid: u32,
    parser: Arc<Mutex<Parser>>,
}

impl PtyProcessInner {
    pub async fn spawn(
        command: Vec<String>,
        size: PtySize,
        cwd: Option<String>,
        output_tx: mpsc::UnboundedSender<Bytes>,
        mut input_rx: mpsc::UnboundedReceiver<Bytes>,
    ) -> Result<Self> {
        // 创建VT100解析器
        let parser = Arc::new(Mutex::new(Parser::new(size.rows, size.cols, 0)));
        let parser_clone = parser.clone();

        // 构建命令
        let cmd = if command.is_empty() {
            vec!["cmd.exe".to_string()]
        } else {
            command
        };

        // 启动进程
        let mut process_builder = Command::new(&cmd[0]);
        process_builder
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .stdin(Stdio::piped());
            
        // 添加命令参数（如果有的话）
        if cmd.len() > 1 {
            process_builder.args(&cmd[1..]);
        }
            
        if let Some(cwd) = cwd {
            process_builder.current_dir(cwd);
        }

        let mut child = process_builder.spawn().context("Failed to spawn process")?;
        let pid = child.id();

        // 获取子进程的stdin和stdout
        let stdin = child.stdin.take().context("Failed to get stdin")?;
        let stdout = child.stdout.take().context("Failed to get stdout")?;
        let stderr = child.stderr.take().context("Failed to get stderr")?;

        // 处理输出数据
        let output_tx_clone = output_tx.clone();
        let parser_output = parser.clone();
        thread::spawn(move || {
            let mut reader = BufReader::new(stdout);
            let mut buffer = [0u8; 1024];
            
            loop {
                match reader.read(&mut buffer) {
                    Ok(0) => break,
                    Ok(n) => {
                        let output = &buffer[..n];
                        
                        // 更新VT100解析器状态
                        let mut parser = parser_output.lock().unwrap();
                        parser.process(output);
                        
                        // 发送原始输出到客户端
                        if output_tx_clone.send(Bytes::copy_from_slice(output)).is_err() {
                            break;
                        }
                    }
                    Err(_) => break,
                }
            }
        });

        // 处理错误输出
        let output_tx_clone = output_tx.clone();
        let parser_error = parser.clone();
        thread::spawn(move || {
            let mut reader = BufReader::new(stderr);
            let mut buffer = [0u8; 1024];
            
            loop {
                match reader.read(&mut buffer) {
                    Ok(0) => break,
                    Ok(n) => {
                        let output = &buffer[..n];
                        
                        // 更新VT100解析器状态
                        let mut parser = parser_error.lock().unwrap();
                        parser.process(output);
                        
                        // 发送原始错误输出到客户端
                        if output_tx_clone.send(Bytes::copy_from_slice(output)).is_err() {
                            break;
                        }
                    }
                    Err(_) => break,
                }
            }
        });

        // 处理输入数据
        let mut stdin_writer = stdin;
        tokio::spawn(async move {
            while let Some(data) = input_rx.recv().await {
                println!("Received input data: {:?}", std::str::from_utf8(&data));
                
                if let Err(e) = stdin_writer.write_all(&data) {
                    eprintln!("Failed to write to stdin: {}", e);
                    break;
                }
                // 立即刷新缓冲区，确保输入立即被处理
                if let Err(e) = stdin_writer.flush() {
                    eprintln!("Failed to flush stdin: {}", e);
                }
                println!("Successfully wrote data to stdin");
            }
        });

        // 监控子进程退出
        tokio::spawn(async move {
            let _ = child.wait();
        });

        Ok(Self {
            pid,
            parser: parser_clone,
        })
    }

    pub fn pid(&self) -> u32 {
        self.pid
    }

    pub async fn resize(&self, size: PtySize) -> Result<()> {
        let mut parser = self.parser.lock().unwrap();
        parser.set_size(size.rows, size.cols);
        Ok(())
    }

    pub async fn kill(&self) -> Result<()> {
        // 在Windows上，我们可以通过其他方式终止进程
        // 这里简单地返回Ok，实际的进程管理由操作系统处理
        Ok(())
    }
}